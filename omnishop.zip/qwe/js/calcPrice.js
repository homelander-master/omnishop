function calcPrice () {
    const cartItems = document.querySelectorAll('.cart__user-item');
    const cartPrice = document.querySelector('.cart-total__price');
    const cartOrderLink = document.querySelector('.cart-order__link');

    let totalPrice = 0;
    cartItems.forEach(function (item) {
        
        const itemPrice = item.querySelector('.cart-price');

        totalPrice = totalPrice + parseInt(itemPrice.innerText);
        console.log(totalPrice);
    })
    cartPrice.innerText = totalPrice;
    const cartItemHTML = `
    <input type="hidden" name="total_price" value="${totalPrice}">
    `
    cartOrderLink.insertAdjacentHTML('beforeend', cartItemHTML);
}
window.onload = calcPrice();