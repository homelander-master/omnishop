
const orderTitle = document.querySelector('.order-title');

window.addEventListener('click', function(event) {
    if(event.target.hasAttribute('data-order')) {
        const parent = event.target.closest('.data-order');
        const orderCart = parent.querySelector('.cart-order');
        console.log(parent);
        console.log(event.target);
        if(event.target.classList.contains("active")) {
            event.target.classList.remove('active');
            orderCart.classList.remove('active')
        } 
        else {
            event.target.classList.add('active');
            orderCart.classList.add('active')
        }
    }
})