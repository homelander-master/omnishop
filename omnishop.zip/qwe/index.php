<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>omnishop</title>
  <link href="https://fonts.googleapis.com/css2?family=Bungee&display=swap" rel="stylesheet"> <link rel="stylesheet" href="css/style.css">

</head>
<body>
<!-- partial:index.partial.html -->

<div class="background-one">
  <div class="link-container">
    <a class="link-one" href="keyboards.php">Клавиатуры</a>
  </div>
</div>
<div class="background-two link-container">
  <a class="link-two" href="mouse.php">Мышки</a>
</div>
<div class="background-three link-container">
  <a class="link-three" href="other.php">Аксессуары</a>
</div>
<!-- partial -->
  
</body>
</html>
