<?php
$db = mysqli_connect("localhost", "root", "", "authorization_tutorial");